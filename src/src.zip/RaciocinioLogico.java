import java.util.ArrayList;


public class RaciocinioLogico extends Enigmas {

	public RaciocinioLogico(int qtdAtivacoes, int qtdUsos, int qtdDecifrados, int qtdErros, String descricao) {
		super(qtdAtivacoes, qtdUsos, qtdDecifrados, qtdErros, descricao, level);
		// TODO Auto-generated constructor stub
	}

}
