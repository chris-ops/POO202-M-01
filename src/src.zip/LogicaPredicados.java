

public class LogicaPredicados extends Enigmas{

	public LogicaPredicados(int qtdAtivacoes, int qtdUsos, int qtdDecifrados, int qtdErros, String descricao) {
		super(qtdAtivacoes, qtdUsos, qtdDecifrados, qtdErros, descricao, level);
		// TODO Auto-generated constructor stub
	}

	
	

}
